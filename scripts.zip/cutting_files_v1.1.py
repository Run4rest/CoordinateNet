#import tensorflow as tf
import numpy as np
#import scipy as sp
#import sklearn as skl
#import matplotlib.pyplot as plt
import pandas as pd
import random
#import math
import os
#import glob
import librosa as lba
#import librosa.display as lid
import soundfile as sf
import noise as noise
from pathlib import Path
#from tensorflow import keras
#from keras import layers
#from keras import models
#from keras import regularizers
from sklearn.model_selection import train_test_split
#from sklearn.cluster import KMeans
#from sklearn.metrics import silhouette_score
from datetime import datetime#, date, timedelta
from numpy.random import default_rng
#from keras.layers import Dense, Concatenate, Input, Lambda
#from keras.models import Model
#from matplotlib.gridspec import GridSpec

WORKING_DIRECTORY = 'C:/BirdCLEF23/'
os.chdir (WORKING_DIRECTORY)

CONFIG = '_config.html'
cfg = pd.read_html (CONFIG)[0]
cfg.columns = ['param', 'value']

fpLog  = Path ('./logs/log cutting_files_v1.1.txt')

with open (fpLog, 'w') as flog:
    print ('cutting_files_v1.1 has started at : ', datetime.now(), file = flog)
    print ('CONFIG : \n', cfg, file = flog)

REGISTRY_SAMS = cfg.loc[(cfg['param'] == 'REGISTRY_SAMS'), ['value']].iloc[0]['value']
FILESTOCUT = cfg.loc[(cfg['param'] == 'FILESTOCUT'), ['value']].iloc[0]['value']
DIR_SAMS = cfg.loc[(cfg['param'] == 'DIR_SAMS'), ['value']].iloc[0]['value']
NICKS = cfg.loc[(cfg['param'] == 'NICKS'), ['value']].iloc[0]['value']
SR = cfg.loc[(cfg['param'] == 'SR'), ['value']].iloc[0].astype(int)['value']
HOP = cfg.loc[(cfg['param'] == 'HOP'), ['value']].iloc[0].astype(int)['value']
MAXNUMBER = cfg.loc[(cfg['param'] == 'MAXNUMBER'), ['value']].iloc[0].astype(int)['value']
iSR5 = 32000*5

with open (fpLog, 'a') as flog:
    print ('FILESTOCUT : ', FILESTOCUT, file = flog)
    print ('NICKS : ', NICKS, file = flog)
    print ('DIR_SAMS : ', DIR_SAMS, file = flog)
    print ('SR : ', SR, file = flog)
    print ('HOP : ', HOP, file = flog)
    print ('MAXNUMBER : ', MAXNUMBER, file = flog)
    print ('REGISTRY_SAMS : ', REGISTRY_SAMS, file = flog)

SEED = 2276
rng = default_rng (SEED)
np.random.seed (SEED)
os.environ['PYTHONHASHSEED'] = str(SEED)

# Params of noise

LOWFR = 4000
UPFR  = 9000

trn_registry = [] 

_df_ = pd.read_html (FILESTOCUT, encoding ='utf-8')[0]
dfn = pd.read_html (NICKS, encoding ='utf-8')[0]
_df_ = _df_.merge (dfn [['fname', 'nicks']], on = 'fname', how = 'left')

# Forming train samples 

df = _df_.loc[~((_df_['trn_list'].isna()) & (_df_['val_list'].notna()))] # filtering out files with validation samples only


df['val_list'] = df.val_list.fillna('[]')
dft1 = df.loc[df.type == 1] 

for idx, row in dft1.iterrows():

    with open (fpLog, 'a') as flog:
        print (row.bird, file = flog)
        print (row.fname, file = flog)

    sbdir = DIR_SAMS + row.bird  
    os.makedirs (Path (sbdir), exist_ok = True)

    nax, _ = lba.load (row.fname, sr = SR, res_type = "kaiser_fast", mono = True)
    
    if nax.shape[0] < iSR5: 
        na = np.zeros (iSR5)
        na[iSR5//2 - nax.shape[0]//2 : iSR5//2 - nax.shape[0]//2 + nax.shape[0]] = nax[...]
        nax = na

    ltrn  = [int(x) for x in eval (row.trn_list)]
    lval  = [int(x) for x in eval (row.val_list)]
    
    lmark = [0 for x in range (nax.shape[0]//iSR5)]
    for itrn in ltrn: lmark[itrn] = 1

    lval.sort (reverse = 1)

    for x in lval: del lmark[x]

    lsams = [i for i, x in enumerate(lmark) if x == 1]

#    if (len (ltrn) != len (lsams)): print (len (ltrn), len (lsams))

    nac = np.concatenate ([nax[x*iSR5 : (x + 1)*iSR5] for x in range (nax.shape[0]//iSR5) if x not in lval])
    if nax.shape[0]%iSR5 > 0: nac = np.concatenate ([nac, nax[-(nax.shape[0]%iSR5) : -1]]) 

    lnicks = [min ([x*HOP, nax.shape[0] - 1]) for x in eval (row.nicks)]
    _nax_ = np.zeros (nax.shape[0], dtype = int)
    _nax_[lnicks] = 1
    _nax_ = np.concatenate ([_nax_[x*iSR5 : (x + 1)*iSR5] for x in range (nax.shape[0]//iSR5) if x not in lval])

#    for iup in range (row.up):
    for iup in range (row.up//3 + 1):

        for i_, k in enumerate (lsams):

            nas = _nax_[k*iSR5 : (k+1)*iSR5]
            min_nick = nas.argmax()
            max_nick = nas.shape[0] - np.flip (nas).argmax() - 1
            mid = (min_nick + max_nick)//2 

#            ipos = 0 if iup == 0 else int ((min_nick + max_nick)/2 - iSR5/2 + rng.uniform (-iSR5*3//8, iSR5*3//8))

            _la_ = []; _lp_ = []

            pb = (3*row.pb - 1)/2.0
            pb = pb if pb > 0.0 else 0.0
            lpb = [1, pb, pb]

            for ia_ in [0, 1, 2]:
                if rng.uniform (0.0, 1.0) < lpb[ia_]: 
                    _lp_.append (0 if iup == 0 and ia_ == 0 else int (mid - iSR5//2 + rng.uniform (-iSR5*3//8, iSR5*3//8)))

            nac_ex = np.zeros (nac.shape[0] + 2*iSR5)
            nac_ex[iSR5 : iSR5 + nac.shape[0]] = nac

            for m, ipos in enumerate (_lp_):

                _na_ = nac_ex[(k+1)*iSR5 + ipos : (k+2)*iSR5 + ipos]

                nlvl   = rng.uniform (0.1, 0.3)
                bfreq  = rng.uniform (200, 750)
                lowfr  = LOWFR
                upfr   = UPFR
                upsgm  = 0.14*rng.uniform (3, 6)
                up2low = rng.uniform (0.1, 0.3)

                _noise_ = 0 if iup == 0 else noise.get_noise (_na_, nlvl, bfreq, lowfr, upfr, upsgm, up2low, rng, SR)

                _na_ = _na_ + _noise_

                _la_.append (_na_)

            sname = sbdir + '/' + row.fname.split('/')[-1].split('.')[-2] + '_T1_{0:02}'.format(iup)
            for m, _na_ in enumerate (_la_):
#                _sname_ = sname + '_{0:02}'.format (k) + '_{0:02}.wav'.format (m)
                _sname_ = sname + '_{0:02}'.format (ltrn[i_]) + '_{0:02}.wav'.format (m)

                sf.write (_sname_, _na_, SR)

                trn_registry += [_sname_]

#            _na_ = nac_ex[(k+1)*iSR5 + ipos : (k+2)*iSR5 + ipos]

#            nlvl   = rng.uniform (0.1, 0.3)
#            bfreq  = rng.uniform (200, 750)
#            lowfr  = LOWFR
#            upfr   = UPFR
#            upsgm  = 0.14*rng.uniform (3, 6)
#            up2low = rng.uniform (0.1, 0.3)

#            _na_ = _na_ + noise.get_noise (_na_, nlvl, bfreq, lowfr, upfr, upsgm, up2low, rng, SR)

#            sname = sbdir + '/' + row.fname.split('/')[-1].split('.')[-2] + '_T1_{0:02}_{1:02}.wav'.format(iup, int(ltrn[i_]))

#            sf.write (sname, _na_, SR)

#            trn_registry += [sname]


dft2 = df.loc[df.type == 2] 

for idx, row in dft2.iterrows():

    sbdir = DIR_SAMS + row.bird  
    os.makedirs (Path (sbdir), exist_ok = True)

    nax, _ = lba.load (row.fname, sr = SR, res_type = "kaiser_fast", mono = True)
    
    if nax.shape[0] < iSR5: 
        na = np.zeros (iSR5)
        na[iSR5//2 - nax.shape[0]//2 : iSR5//2 - nax.shape[0]//2 + nax.shape[0]] = nax[...]
        nax = na

    ltrn  = [int(x) for x in eval (row.trn_list)]
    lval  = [int(x) for x in eval (row.val_list)]
    
    lmark = [0 for x in range (nax.shape[0]//iSR5)]
    for itrn in ltrn: lmark[itrn] = 1

    lval.sort (reverse = 1)

    for x in lval: del lmark[x]

    lsams = [i for i, x in enumerate (lmark) if x == 1]

    nac = np.concatenate ([nax[x*iSR5 : (x + 1)*iSR5] for x in range (nax.shape[0]//iSR5) if x not in lval])

    naw = np.concatenate ((np.zeros (iSR5//2), nac, np.zeros (iSR5//2)))

    for iup in [0, 1, 2]:

        ind0 = int (rng.uniform (0, 3/4*iSR5)) if iup > 0 else iSR5//2 
        ind1 = ind0 + len (lsams)*iSR5
        nac = naw[ind0 : ind1]

        nlvl   = rng.uniform (0.1, 0.3)
        bfreq  = rng.uniform (200, 750)
        lowfr  = LOWFR
        upfr   = UPFR
        upsgm  = 0.14*rng.uniform (3, 6)
        up2low = rng.uniform (0.1, 0.3)

        nac = nac + (noise.get_noise (nac, nlvl, bfreq, lowfr, upfr, upsgm, up2low, rng, SR) if iup > 0 else 0)

        for k in range (len (lsams)):
            _na_ = nac[k*iSR5: (k+1)*iSR5]
            sname = sbdir + '/' + row.fname.split('/')[-1].split('.')[-2] + '_T2_{0:02}_{1:02}.wav'.format(iup, int (ltrn[k]))
            sf.write (sname, _na_, SR)
            trn_registry += [sname]


# Forming validation samples

val_registry = []

dv = _df_.loc[_df_['val_list'].notna()] # leave only train records

for idx, row in dv.iterrows():

    sbdir = DIR_SAMS + row.bird  
    os.makedirs (Path (sbdir), exist_ok = True)

    nax, _ = lba.load (row.fname, sr = SR, res_type = "kaiser_fast", mono = True)
    
    if nax.shape[0] < iSR5: 
        na = np.zeros (iSR5)
        na[iSR5//2 - nax.shape[0]//2 : iSR5//2 - nax.shape[0]//2 + nax.shape[0]] = nax[...]
        nax = na

    lval = [int(x) for x in eval (row.val_list)]

    for k in lval:
        _na_ = nax[k*iSR5: (k+1)*iSR5]
        sname = sbdir + '/' + row.fname.split('/')[-1].split('.')[-2] + '_V_{0:02}.wav'.format(k)

        sf.write (sname, _na_, SR)

        val_registry += [sname]

#print ('len (val_registry): ', len (val_registry))

dtrn = pd.DataFrame ({
    'sname' : trn_registry, 
    'bird'  : [x.split('/')[-2] for x in trn_registry], 
    'split':'TRN', 
#    'sid' : range (len (trn_registry)),
    })

dtrn = dtrn.groupby (by = ['bird']).apply (lambda x: x if x.shape[0] < MAXNUMBER else x.sample (MAXNUMBER, random_state = SEED))
dtrn = dtrn.reset_index (drop = True)

#dg = dtrn.groupby (by = ['bird']).agg ({'sid': lambda x: list(x)})

#ltrn = []

#for idx, row in dg.iterrows():
#    ltrn += row.sid if len (row.sid) < MAXNUMBER else random.sample (row.sid, int (MAXNUMBER))

#dtrn = dtrn.merge (pd.DataFrame ({'sid' : ltrn}), on = 'sid', how = 'inner')[['sname', 'bird']]

dval = pd.DataFrame ({
    'sname' : val_registry, 
    'bird'  : [x.split('/')[-2] for x in val_registry],
    'split':'VAL', 
    })

drs = pd.concat ([dtrn, dval], axis = 0, ignore_index = True)
drs.to_html (REGISTRY_SAMS, encoding = 'UTF-8')
drsg = drs.groupby (by = ['bird', 'split']).agg (count = ('sname','count')).unstack (level=-1)
drsg.to_html ('./config 264b v2.1/registry sams stat.html', encoding = 'UTF-8')


with open (fpLog, 'a') as flog:
    print ('cutting_files_v1.1 has finished at : ', datetime.now(), file = flog)
