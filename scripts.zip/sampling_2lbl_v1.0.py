#import tensorflow as tf
import numpy as np
#import scipy as sp
#import sklearn as skl
#import matplotlib.pyplot as plt
import pandas as pd
#import pickle
#import math
import os
import glob
#import librosa as lba
#import librosa.display as lid
#import soundfile as sf
#import random
from pathlib import Path
#from tensorflow import keras
#from keras import layers
#from keras import models
#from keras import regularizers
#from sklearn.model_selection import train_test_split
#from sklearn.cluster import KMeans
#from sklearn.metrics import silhouette_score
from datetime import datetime#, date, timedelta
#from numpy.random import default_rng
#from keras.layers import Dense, Concatenate, Input, Lambda
#from keras.models import Model
#from matplotlib.gridspec import GridSpec

WORKING_DIRECTORY = 'C:/BirdCLEF23/'
os.chdir (WORKING_DIRECTORY)

CONFIG = '_config.html'

cfg = pd.read_html (CONFIG)[0]
cfg.columns = ['param', 'value']

fpLog = Path ('./logs/log sampling 2lbl v1.0.txt')

with open (fpLog, 'w') as flog:
    print ('sampling 2lbl v1.0 has started at : ', datetime.now(), file = flog)
    print ('CONFIG : \n', cfg, file = flog)

FILES_2LBL = cfg.loc[(cfg['param'] == 'FILES_2LBL'), ['value']].iloc[0]['value']
SAMS2 = cfg.loc[(cfg['param'] == 'SAMS2'), ['value']].iloc[0]['value']

SR = cfg.loc[(cfg['param'] == 'SR'), ['value']].iloc[0].astype(int)['value']
iSR5 = SR*5

with open (fpLog, 'a') as flog:
    print ('FILES_2LBL : ', FILES_2LBL, file = flog)
    print ('SAMS2 : ', SAMS2, file = flog)
    print ('SR : ', SR, file = flog)

#SEED = 2276
#rng = default_rng (SEED)
#np.random.seed (SEED)
#random.seed (SEED)
#os.environ['PYTHONHASHSEED'] = str(SEED)
#tf.random.set_seed (SEED)

df = pd.read_html (FILES_2LBL, encoding = 'UTF-8')[0]

with open (fpLog, 'a') as flog:
    print ('count of 2lbl files to sample: ', df.shape[0], file = flog)

dfs = pd.DataFrame (columns = ['bird', 'fname', 'sams', 'type'])

fcount = 0

for idx, row in df.iterrows():

    icount = row.duration//iSR5

    lsams = [0] if icount == 0 else list (range (icount))

    dfs.loc[fcount] = [row.bird, row.fname, str (lsams), 2]
    fcount += 1

fphtm = Path (SAMS2)  
dfs.to_html (fphtm, index = True)

with open (fpLog, 'a') as flog:
    print ('sampling 2lbl v1.0 has finished at : ', datetime.now(), file = flog)
