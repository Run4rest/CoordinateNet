import numpy as np

def filter (nax, border_freq, suppression):

    nasp = np.fft.rfft (nax)

    S = np.fft.rfftfreq (nax.shape[0])
    _S_ = 0.5*(1 - np.tanh ((S - 0.5*border_freq/16000)*suppression))*S# + 0.001*S
    #_S_ = 0.5*(1 - np.tanh ((S - 0.5*border_freq/16000)*suppression))*S

    _nasp_ = nasp * _S_
    #_nax_ = np.fft.irfft (_nasp_)
    #return _nax_
    return np.resize (np.fft.irfft (_nasp_), nax.size)
    
def filter_low (nax, border_freq, suppression):

    nasp = np.fft.rfft (nax)

    S = np.fft.rfftfreq (nax.shape[0])
    _S_ = 0.5*(1 + np.tanh ((S - 0.5*border_freq/16000)*suppression))*S# + 0.001*S
    #_S_ = 0.5*(1 - np.tanh ((S - 0.5*border_freq/16000)*suppression))*S

    _nasp_ = nasp * _S_
    #_nax_ = np.fft.irfft (_nasp_)
    #return _nax_
    return np.resize (np.fft.irfft (_nasp_), nax.size)
