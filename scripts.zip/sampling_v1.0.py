#import tensorflow as tf
import numpy as np
#import scipy as sp
#import sklearn as skl
#import matplotlib.pyplot as plt
import pandas as pd
#import pickle
#import math
import os
import glob
import librosa as lba
#import librosa.display as lid
#import soundfile as sf
#import random 
from pathlib import Path
#from tensorflow import keras
#from keras import layers
#from keras import models
#from keras import regularizers
#from sklearn.model_selection import train_test_split
#from sklearn.cluster import KMeans
#from sklearn.metrics import silhouette_score
from datetime import datetime #, date, timedelta
#from numpy.random import default_rng
#from keras.layers import Dense, Concatenate, Input, Lambda
#from keras.models import Model
#from matplotlib.gridspec import GridSpec

WORKING_DIRECTORY = 'C:/BirdCLEF23/'
os.chdir (WORKING_DIRECTORY)

CONFIG = '_config.html'

cfg = pd.read_html (CONFIG)[0]
cfg.columns = ['param', 'value']

fpLog  = Path ('log sampling v4.0.txt')

with open (fpLog, 'w') as flog:
    print ('sampling v4.0 has started at : ', datetime.now(), file = flog)
    print ('CONFIG : \n', cfg, file = flog)

MODE = cfg.loc[(cfg['param'] == 'MODE'), ['value']].iloc[0]['value']
NICKS = cfg.loc[(cfg['param'] == 'NICKS'), ['value']].iloc[0]['value']
SAMS1 = cfg.loc[(cfg['param'] == 'SAMS1'), ['value']].iloc[0]['value']
DIR_DATA = cfg.loc[(cfg['param'] == 'DIR_DATA'), ['value']].iloc[0]['value']

SR = cfg.loc[(cfg['param'] == 'SR'), ['value']].iloc[0].astype(int)['value']; 
HOP = cfg.loc[(cfg['param'] == 'HOP'), ['value']].iloc[0].astype(int)['value']
iSR5 = 5*SR

with open (fpLog, 'a') as flog:
    print ('\nMODE : ', MODE, file = flog)
    print ('NICKS : ', NICKS, file = flog)
    print ('SAMS1 : ', SAMS1, file = flog)
    print ('DIR_DATA : ', DIR_DATA, file = flog)
    print ('SR : ', SR, file = flog)
    print ('HOP : ', HOP, file = flog)

HOTTHSH = 0.75

#SEED = 2276
#rng = default_rng (SEED)
#np.random.seed (SEED)
#random.seed (SEED)
#os.environ['PYTHONHASHSEED'] = str(SEED)
#tf.random.set_seed (SEED)

fp = Path (NICKS) 
dfn = pd.read_html (fp, encoding ='utf-8')[0]

with open (fpLog, 'a') as flog:
    print ('Number of files : ', dfn.shape[0], file = flog)

dfs = pd.DataFrame (columns = ['bird', 'fname', 'sams', 'type'])

fcount = 0
for idx, row in dfn.iterrows():

    fcount += 1

    icount = row.duration//iSR5

    lnicks = pd.eval (row.nicks)
    lnicks = [np.minimum (x*HOP, row.duration - 1) for x in lnicks]
    _nax_ = np.zeros (row.duration, dtype = int)
    _nax_[lnicks] = 1

    lsams = []

    if icount == 0 and np.sum (_nax_) > 0: lsams += [0]

    for i in range (icount):
        nas = _nax_[i*iSR5 : (i+1)*iSR5]
        if np.sum (nas) > 0: lsams += [i]

    itype = 1 if (np.sum (_nax_) < HOTTHSH*row.duration/HOP) or icount == 0 else 2
    dfs.loc[fcount-1] = [row.bird, row.fname, str (lsams), itype]

fphtm = Path (SAMS1)  
dfs.to_html (fphtm, index = True)

with open (fpLog, 'a') as flog:
    print ('sampling v4.0 has finished at : ', datetime.now(), file = flog)
