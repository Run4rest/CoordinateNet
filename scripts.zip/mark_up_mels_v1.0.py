import tensorflow as tf
import numpy as np
import scipy as sp
import sklearn as skl
import matplotlib.pyplot as plt
import pandas as pd
import pickle
import math
import os
import random
import librosa as lba
import librosa.display as lid
import soundfile as sf
from pathlib import Path
from tensorflow import keras
from keras import layers
from keras import models
from keras import regularizers
from sklearn.model_selection import train_test_split
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from datetime import datetime, date, timedelta
from numpy.random import default_rng
from keras.layers import Dense, Concatenate, Input, Lambda
from keras.models import Model

#WORKING_DIRECTORY = 'C:/BirdCLEF23/temp/_lotcor1_/'
WORKING_DIRECTORY = 'C:/BirdCLEF23/'
os.chdir (WORKING_DIRECTORY)


CONFIG = '_config.html'

cfg = pd.read_html (CONFIG)[0]

cfg.columns = ['param', 'value']


fpLog  = Path ('log mark up mels v4.0.txt')

with open (fpLog, 'w') as flog:
    print ('mark up mels v4.0 has started at : ', datetime.now(), file = flog)
    print ('CONFIG : \n', cfg, file = flog)


MODE = cfg.loc[(cfg['param'] == 'MODE'), ['value']].iloc[0]['value']

FILES_2MRK = cfg.loc[(cfg['param'] == 'FILES_2MRK'), ['value']].iloc[0]['value']
NICKS = cfg.loc[(cfg['param'] == 'NICKS'), ['value']].iloc[0]['value']

DIR_DATA = cfg.loc[(cfg['param'] == 'DIR_DATA'), ['value']].iloc[0]['value']
BIRDS2BANDS = cfg.loc[(cfg['param'] == 'BIRDS2BANDS'), ['value']].iloc[0]['value']

SR = cfg.loc[(cfg['param'] == 'SR'), ['value']].iloc[0].astype(int)['value']
HOP = cfg.loc[(cfg['param'] == 'HOP'), ['value']].iloc[0].astype(int)['value']
BANDWIDTH = cfg.loc[(cfg['param'] == 'BANDWIDTH'), ['value']].iloc[0].astype(int)['value']

with open (fpLog, 'a') as flog:
    print ('\nMODE : ', MODE, file = flog)
    print ('FILES_2MRK : ', FILES_2MRK, file = flog)
    print ('NICKS : ', NICKS, file = flog)
    print ('DIR_DATA : ', DIR_DATA, file = flog)
    print ('BIRDS2BANDS : ', BIRDS2BANDS, file = flog)
    print ('SR : ', SR, file = flog)
    print ('HOP : ', HOP, file = flog)
    print ('BANDWIDTH : ', BANDWIDTH, file = flog)


THRESHOLD = 0.7
WNDW = 40
THSD1 = WNDW/2
THSD2 = 0.6

SEED = 2276
rng = default_rng (SEED)
np.random.seed (SEED)
random.seed (SEED)
os.environ['PYTHONHASHSEED'] = str(SEED)
tf.random.set_seed (SEED)

fpb2b = Path (BIRDS2BANDS)

dfb = pd.read_html (fpb2b, encoding = 'UTF-8')[0].dropna()

dfb.set_index (['bird'], inplace = True)

df = pd.DataFrame (columns = ['bird', 'fname', 'nicks', 'duration'])

#lbirds = list (dfb.index.values)

ifcount = 0

fpf = Path (FILES_2MRK)

dff = pd.read_html (fpf, encoding = 'UTF-8')[0]
dff.set_index (['bird'], inplace = True)

lbirds = list (dff.index.unique())

for i, bname in enumerate (lbirds):

    if not os.path.isdir (DIR_DATA + bname):
        continue

    bar1 = int (dfb.loc[[bname],['bardown']].bardown.item())
    bar2 = int (dfb.loc[[bname],['barup']].barup.item())

    dffb = dff.loc[[bname]]
    with open (fpLog, 'a') as flog:
        print (f'Number of audios for {bname}: {dffb.shape[0]}', datetime.now(), file = flog)

    #lini = list (dffb[dffb.flag == True].fname)
    lini = list (dffb.fname)

    for fname in lini:

        fp = Path (fname)
        nax, _ = lba.load (fp, sr = SR, res_type = "kaiser_fast", mono = True)
        size = nax.shape[0]

        _spec_ = lba.feature.melspectrogram (y = nax, sr=SR, n_mels = 128, n_fft = 1024, hop_length = HOP, fmax = 16000, fmin = 20)
        _spec_ = lba.power_to_db (_spec_, ref = np.max)

        spec = np.abs(_spec_ + 80.0)
        spec = np.reshape (spec, (128//BANDWIDTH, BANDWIDTH, -1))
        spec = spec[bar1-1:bar2, ...]

        spec = np.sum (spec, axis = 1)
        mind = np.argpartition (spec, -3, -1)[:, -3:]
        top3 = np.take_along_axis (spec, mind, axis = -1)
        smax = np.sum (top3, axis = -1)/3

        ind = np.argmax (smax)
        nax = spec[ind]/np.amax (spec[ind])
        ixmask = np.ix_((nax > THRESHOLD),)

        ns0 = np.zeros(_spec_.shape[1], dtype = int)
        ns0[ixmask[0]] = 1
        nsa = np.zeros (ns0.shape[0] - WNDW + 1, dtype = int)

        for m in range (nsa.shape[0]):
            nsa[m] = np.sum (ns0[m : m + WNDW])

        ixwide = np.ix_((nsa >= THSD1),)
        nnicks = ixmask[0] if ixwide[0].shape[0]/ixmask[0].shape[0] < THSD2 else ixwide[0]

        df.loc[ifcount] = [bname, fname, str (list (nnicks)), size]
        ifcount += 1

    try:
        if i % (len(lbirds)//10) == 0:
    #    if i % (len(lbirds)//2) == 0:
            with open (fpLog, 'a') as flog:
                print ('count of birds in progress = ', i, '  ', datetime.now(), file = flog)
    except ZeroDivisionError as error:
        with open (fpLog, 'a') as flog:
            print ('Value error : ', error, file = flog)
        pass

#        for j in range (ixmask[0].shape[0]):
#            _spec_[(ind + bar1 - 1)*BANDWIDTH:(ind + bar1)*BANDWIDTH, ixmask[0][j] - 4:ixmask[0][j] + 4] = -5
#        lid.specshow (_spec_, sr = SR, hop_length = 400, n_fft=1024, fmin=20, fmax=16000, x_axis = 'time', y_axis = 'mel')
#        plt.show()

fphtm = Path (NICKS)  
df.to_html (fphtm, index = True)

with open (fpLog, 'a') as flog:
    print ('Stop mark up mels v3.0 at : ', datetime.now(), file = flog)
