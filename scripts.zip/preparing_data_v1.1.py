#import tensorflow as tf
import numpy as np
#import scipy as sp
#import sklearn as skl
#import matplotlib.pyplot as plt
import pandas as pd
import random
import os
#import sys
#import shutil
#import glob
#import librosa as lba
#import librosa.display as lid
#import soundfile as sf
from pathlib import Path
#from tensorflow import keras
#from keras import layers
#from keras import models
#from keras import regularizers
#from keras.constraints import max_norm
from sklearn.model_selection import train_test_split
#from sklearn.cluster import KMeans
from datetime import datetime #, date, timedelta
from numpy.random import default_rng
#from keras import backend as K
#from matplotlib.gridspec import GridSpec

WORKING_DIRECTORY = 'C:/BirdCLEF23/'
os.chdir (WORKING_DIRECTORY)


CONFIG = '_config.html'

cfg = pd.DataFrame.from_dict (
    {
        'MODE' : 'FULL',    
        'DIR_DATA':'./data/train_audio/',
        'META' : './data/train_metadata.html',
        'DIR_SAMS' : './sams/264b v2.1/',
        'DIR_MELS' : './mels/264b v2.1/',
#        'DIR_SAVE' : './files to correct/',
        'FILES' : './config 264b v2.1/files v3.0.html',
        'NICKS' : './config 264b v2.1/nicks (264b).html',
        'SAMS1' : './config 264b v2.1/sams1 (264b).html',
        'SAMS2' : './config 264b v2.1/sams2 (264b).html',
        'FILES_2LBL' : './config 264b v2.1/2lbl sampling (264b).html',
        'FILES_2MRK' : './config 264b v2.1/files 2markup (264b).html',
        'BIRDS2BANDS' : './config 264b v2.1/birds2bands.html',
        'FR2BAR': './config 264b v2.1/fr2bar.html',
        'SR' : 32000,
        'HOP': 400,
        'BANDWIDTH': 4, # it is band width to mark up, not for the model! 
        'FILESTOCUT' : './config 264b v2.1/files to cut.html', # List of birds with number of files less than MINNUMBER
        'MINNUMBER' : 400,                       # minimum number of files for each bird
        'MAXNUMBER' : 2500,                       # maximum number of files for each bird
        'RATING' : 3.0,
        'REGISTRY_SAMS': './config 264b v2.1/registry_sams.html',
        'REGISTRY_MELS': './config 264b v2.1/registry_mels.html',
    },  
    columns = ['value'],
    orient = 'index'
)

cfg.to_html (CONFIG, encoding = 'UTF-8')

cfg.reset_index (inplace = True)
cfg.columns = ['param', 'value']

fpGLog  = Path ('./logs/log preparing_data_v1.1.txt')

with open (fpGLog, 'w') as flog:
    print ('preparing_data_v1.1 has started at : ', datetime.now(), file = flog)
    print ('CONFIG : \n', cfg, file = flog)

DIR_DATA = cfg.loc[(cfg['param'] == 'DIR_DATA'), ['value']].iloc[0]['value']
DIR_MELS = cfg.loc[(cfg['param'] == 'DIR_MELS'), ['value']].iloc[0]['value']
FILES = cfg.loc[(cfg['param'] == 'FILES'), ['value']].iloc[0]['value']
FILES_2MRK = cfg.loc[(cfg['param'] == 'FILES_2MRK'), ['value']].iloc[0]['value']
FILES_2LBL = cfg.loc[(cfg['param'] == 'FILES_2LBL'), ['value']].iloc[0]['value']
SAMS1 = cfg.loc[(cfg['param'] == 'SAMS1'), ['value']].iloc[0]['value']
SAMS2 = cfg.loc[(cfg['param'] == 'SAMS2'), ['value']].iloc[0]['value']
NICKS = cfg.loc[(cfg['param'] == 'NICKS'), ['value']].iloc[0]['value']
FILESTOCUT = cfg.loc[(cfg['param'] == 'FILESTOCUT'), ['value']].iloc[0]['value']
RATING = cfg.loc[(cfg['param'] == 'RATING'), ['value']].iloc[0].astype(float)['value']
MINNUMBER = cfg.loc[(cfg['param'] == 'MINNUMBER'), ['value']].iloc[0].astype(int)['value']
MAXNUMBER = cfg.loc[(cfg['param'] == 'MAXNUMBER'), ['value']].iloc[0].astype(int)['value']
SR = cfg.loc[(cfg['param'] == 'SR'), ['value']].iloc[0].astype(int)['value']
iSR5 = SR*5

with open (fpGLog, 'a') as flog:
    print ('DIR_DATA : ', DIR_DATA, file = flog)
    print ('DIR_MELS : ', DIR_MELS, file = flog)
    print ('FILES : ', FILES, file = flog)
    print ('FILES_2MRK : ', FILES_2MRK, file = flog)
    print ('FILES_2LBL : ', FILES_2LBL, file = flog)
    print ('SAMS1 : ', SAMS1, file = flog)
    print ('SAMS2 : ', SAMS2, file = flog)
    print ('NICKS : ', NICKS, file = flog)
    print ('FILESTOCUT : ', FILESTOCUT, file = flog)
    print ('RATING : ', RATING, file = flog)
    print ('MINNUMBER : ', MINNUMBER, file = flog)
    print ('MAXNUMBER : ', MAXNUMBER, file = flog)
    print ('SR : ', SR, file = flog)

SEED = 2276
rng = default_rng (SEED)
np.random.seed (SEED)
random.seed (SEED)
os.environ['PYTHONHASHSEED'] = str(SEED)
#tf.random.set_seed (SEED)

# Creating birds2bands.html

with open (fpGLog, 'a') as flog: print ('starting bands_v1.0 : ', datetime.now(), file = flog)

with open ('./code/bands_v1.0.py') as code: exec (code.read())

# Updating files v3.0.html

with open (fpGLog, 'a') as flog: print ('starting files_v1.0 : ', datetime.now(), file = flog)

with open ('./code/files_v1.0.py') as code: exec (code.read())

# Selecting files

with open (fpGLog, 'a') as flog: print ('selecting files for sampling has started at : ', datetime.now(), file = flog)

df = pd.read_html (FILES)[0]

#df = df.loc [df['bird'].isin(
#                                [
#                                'golher1','rehblu1','chtapa3', \
#                                'mouwag1','gyhbus1','grbcam1', \
#                                'yertin1','fotdro5','wlwwar'
#                                ]
#                            )]

# Preparing two lists of files:
# - FILES_2MRK contains files for marking up. These are files with no 2lbl
# - FILES_2LBL contains files that will cut into simple consecutive 5s intervals. These are 2lbl files

df['length_2l'] = np.where (df['2lbl'] != '[]', df.length, 0)

dfs = df.loc [(df['rating'] >= RATING) & (df['flag'] == True)]

#df1l = dfs.loc[(dfs['2lbl'] == '[]') | (dfs['bird'] == 'lotcor1'), ['bird','fname', '2lbl', 'duration', 'length', 'length_2l']].reset_index (drop = True)
df1l = dfs.loc[(dfs['2lbl'] == '[]'), ['bird','fname', '2lbl', 'duration', 'length', 'length_2l']].reset_index (drop = True)
df1l.to_html (FILES_2MRK, encoding = 'UTF-8')

#df2l = dfs.loc[(dfs['2lbl'] != '[]') & (dfs['bird'] != 'lotcor1'), ['bird','fname', '2lbl', 'duration', 'length', 'length_2l']].reset_index (drop = True)
df2l = dfs.loc[(dfs['2lbl'] != '[]'), ['bird','fname', '2lbl', 'duration', 'length', 'length_2l']].reset_index (drop = True)
df2l.to_html (FILES_2LBL, encoding = 'UTF-8')

dfsg = dfs.groupby (['bird']).agg ({'length': ['sum', 'count'], 'length_2l': ['sum']})
dfsg.sort_values (by = ('length', 'sum')).to_html ('./config 264b v2.1/files 264 birds stat.html')

# Marking up of FILES_2MRK files

with open (fpGLog, 'a') as flog: print ('starting mark_up_mels_v1.0 : ', datetime.now(), file = flog)

with open ('./code/mark_up_mels_v1.0.py') as code: exec (code.read())

# Sampling marked up files 

with open (fpGLog, 'a') as flog: print ('starting sampling_v1.0 : ', datetime.now(), file = flog)

with open ('./code/sampling_v1.0.py') as code: exec (code.read())

# Sampling FILES_2LBL files

with open (fpGLog, 'a') as flog: print ('starting sampling_2lbl_v1.0.py : ', datetime.now(), file = flog)

with open ('./code/sampling_2lbl_v1.0.py') as code: exec (code.read())

# Now we got two lists of samples:
# - samples after marking up
# - simple 5 second intevals   
# We bring them to a convenient format, union them and limit the number of samples per bird to MAXNUMBER

fsm1 = Path (SAMS1) 
dsm1 = pd.read_html (fsm1, encoding ='utf-8')[0].drop (['Unnamed: 0'], axis = 1)
dsm1['sams'] = [eval(x) for x in dsm1.sams.tolist()]

dr1 = pd.DataFrame({
      col:np.repeat(dsm1[col].values, dsm1['sams'].str.len())
      for col in dsm1.columns.drop('sams')}
    ).assign (**{'sam':np.concatenate (dsm1['sams'].values)})

fsm2 = Path (SAMS2) 
dsm2 = pd.read_html (fsm2, encoding ='utf-8')[0].drop (['Unnamed: 0'], axis = 1)
dsm2['sams'] = [eval(x) for x in dsm2.sams.tolist()]

dr2 = pd.DataFrame({
      col:np.repeat(dsm2[col].values, dsm2['sams'].str.len())
      for col in dsm2.columns.drop('sams')}
    ).assign (**{'sam':np.concatenate (dsm2['sams'].values)})

dr = pd.concat ([dr1, dr2])

dr = dr.reset_index (drop = True).reset_index (names = ['sid'])
#dr.to_html ('./logs/test01.html', encoding = 'UTF-8')

drg = dr.groupby (by = ['bird']).agg ({'sid': lambda x: list(x)})

ldown = []

for idx, row in drg.iterrows():
    ldown += row.sid if len (row.sid) < int (MAXNUMBER/0.9) else random.sample (row.sid, int(MAXNUMBER/0.9))

ddown = pd.DataFrame ({'sid' : ldown})
dr = dr.merge (ddown, on = 'sid', how = 'inner')

# Splitting of samples on a training and a validation sets

drg = dr.groupby (by = ['bird']).agg ({'sid': lambda x: list(x)})

ltrain = []; lval = []

for idx, row in drg.iterrows():
    _ltr_, _lvl_ = train_test_split (row.sid, test_size = 0.1, random_state = SEED)
    ltrain = ltrain + _ltr_; lval = lval + _lvl_

dr.set_index ('sid', inplace = True)

dr['test'] = 0

dr.loc[lval, ['test']] = 1

dr.to_html ('./config 264b v2.1/samples splitted.html')

# Calculating of test and total samples count per bird

dragg = dr.groupby (by = ['bird']).agg (val = ('test', 'sum'), total = ('test', 'count'))

dragg.to_html ('./config 264b v2.1/samples splitted stat.html')

# Grouping of training samples into lists and counting

dtrn = dr.loc[dr['test'] == 0]
dtrn = dtrn.groupby (by = ['bird', 'fname', 'type']).agg (trn_list = ('sam', lambda x: list(x)), trn_count = ('sam', 'count'))

# Grouping of test samples into lists

dval = dr.loc[dr['test'] == 1]
dval = dval.groupby (by = ['bird', 'fname', 'type']).agg ({'sam': lambda x: list(x)}).rename (columns = {'sam': 'val_list'})

# Counting of training samples of type = 1

# We form base dataset joining of: 
#   - training samples lists 
#   - test samples lists

dfls = dtrn.merge (dval[['val_list']], left_index = True, right_index = True, how = 'outer')

dfls = dfls.reset_index()
dup = dfls.copy()

# Calculating how many times to repeat sampling up

dup = dup.loc[~((dup['trn_list'].isna()) & (dup['val_list'].notna()))]  # excluding of files with val list only

dup['trn1_count'] = np.where (dup['type'] == 1, dup.trn_count, 0)                   
dup['trn2_count'] = np.where (dup['type'] == 2, dup.trn_count, 0)                   

dup = dup.groupby (by = ['bird']).agg ({'trn_count':'sum', 'trn1_count':'sum', 'trn2_count':'sum'})
dup = dup.reset_index ()
dup = dup.reset_index (drop = True)

dup['up'] = np.where (MINNUMBER > dup.trn1_count + 3*dup.trn2_count, ((MINNUMBER - 3*dup.trn2_count)//dup.trn1_count + 1).apply (int), 1)
dup['pb'] = np.where (3*(dup.trn1_count + dup.trn2_count) - MAXNUMBER > 0, (MAXNUMBER/3 - dup.trn2_count)/dup.trn1_count, 1.0)
dup = dup.sort_values (by = ['up'])
dup.to_html ('./config 264b v2.1/times to repeat.html')

dfls = dfls.merge (dup[['up', 'pb', 'bird']], on = 'bird', how = 'left')

dfls.to_html (FILESTOCUT)

with open (fpGLog, 'a') as flog:
    print ('starting cutting_files_v1.1.py : ', datetime.now(), file = flog)

with open ('./code/cutting_files_v1.1.py') as code: exec (code.read())

with open (fpGLog, 'a') as flog:
    print ('starting mels_v2.0.py : ', datetime.now(), file = flog)

with open ('./code/mels_v2.0.py') as code: exec (code.read())

with open (fpGLog, 'a') as flog:
    print ('preparing_data_v1.1 has finished at : ', datetime.now(), file = flog)
    