#import tensorflow as tf
import numpy as np
#import scipy as sp
#import sklearn as skl
#import matplotlib.pyplot as plt
import pandas as pd
#import pickle
#import math
import os
import glob
import librosa as lba
#import librosa.display as lid
#import soundfile as sf
#import random
from pathlib import Path
#from tensorflow import keras
#from keras import layers
#from keras import models
#from keras import regularizers
#from sklearn.model_selection import train_test_split
#from sklearn.cluster import KMeans
#from sklearn.metrics import silhouette_score
from datetime import datetime#, date, timedelta
#from numpy.random import default_rng
#from keras.layers import Dense, Concatenate, Input, Lambda
#from keras.models import Model

WORKING_DIRECTORY = 'C:/BirdCLEF23/'
os.chdir (WORKING_DIRECTORY)

CONFIG = '_config.html'
cfg = pd.read_html (CONFIG)[0]
cfg.columns = ['param', 'value']

fpLog  = Path ('./logs/log mels_v2.0.txt')
with open (fpLog, 'w') as flog:
    print ('mels_v2.0 has started at : ', datetime.now(), file = flog)
    print ('CONFIG : \n', cfg, file = flog)

DIR_SAMS = cfg.loc[(cfg['param'] == 'DIR_SAMS'), ['value']].iloc[0]['value']
DIR_MELS = cfg.loc[(cfg['param'] == 'DIR_MELS'), ['value']].iloc[0]['value']
REGISTRY_SAMS = cfg.loc[(cfg['param'] == 'REGISTRY_SAMS'), ['value']].iloc[0]['value']
REGISTRY_MELS = cfg.loc[(cfg['param'] == 'REGISTRY_MELS'), ['value']].iloc[0]['value']
SR = cfg.loc[(cfg['param'] == 'SR'), ['value']].iloc[0].astype(int)['value']
HOP = cfg.loc[(cfg['param'] == 'HOP'), ['value']].iloc[0].astype(int)['value']


with open (fpLog, 'a') as flog:
    print ('DIR_SAMS : ', DIR_SAMS, file = flog)
    print ('DIR_MELS : ', DIR_MELS, file = flog)
    print ('REGISTRY_SAMS : ', REGISTRY_SAMS, file = flog)
    print ('REGISTRY_MELS : ', REGISTRY_MELS, file = flog)
    print ('SR : ', SR, file = flog)
    print ('HOP : ', HOP, file = flog)

drm = pd.read_html (REGISTRY_SAMS, encoding = 'UTF-8')[0]

#lini = [fname.replace ('\\', '/').replace ('//', '/') for fname in glob.glob (f'{DIR_SAMS}*/*.*')]
lini = drm.sname.tolist()

#if len (lini) > 20:
#    lini = lini[:20]
with open (fpLog, 'a') as flog:
    print ('Total number of samples: ', len (lini), file = flog)

for i, fname in enumerate (lini):

    sbdir = DIR_MELS + fname.split('/')[-2]  
    os.makedirs (Path (sbdir), exist_ok = True)

    fshot = fname.split('/')[-1]
    fmel  = sbdir + '/' + fshot[:len(fshot) - 4] + '.npy'

    nax, _ = lba.load (fname, sr = SR, res_type = "kaiser_fast", mono = True)    
    _spec_ = lba.feature.melspectrogram (y = nax, sr = SR, n_mels = 128, n_fft = 1024, hop_length = HOP, fmax = 16000, fmin = 20)
    _spec_ = lba.power_to_db (_spec_, ref = np.max)

    try:
        if not os.path.isfile (fmel):
            np.save (fmel, _spec_)
    except OSError as error:
        with open (fpLog, 'a') as flog:
            print ('OS error : ', error, file = flog)

    if i % (len (lini)//20) == 0:
        with open (fpLog, 'a') as flog:
            print ('count of files in progress = ', i, '  ', datetime.now(), file = flog)

#drm = pd.read_html (REGISTRY_SAMS, encoding = 'UTF-8')[0]
drm['sname'] = drm['sname'].str.replace (DIR_SAMS, DIR_MELS).str.replace ('.ogg', '.npy').str.replace ('.wav', '.npy')
drm.to_html (REGISTRY_MELS, encoding = 'UTF-8')

drmg = drm.groupby (by = ['bird', 'split']).agg (count = ('sname','count')).unstack (level=-1)
drmg.to_html ('./config 264b v2.0/registry mels stat.html', encoding = 'UTF-8')

with open (fpLog, 'a') as flog:
    print ('mels_v2.0 has finished at: ', datetime.now(), file = flog)
