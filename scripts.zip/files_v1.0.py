import numpy as np
import pandas as pd
import os
import glob
import librosa as lba
from pathlib import Path
from datetime import datetime#, date, timedelta

#This script builds registry of audio files unioning of BirdCLEF23's  audios and some new/derived audios. 
# It introduses a boolean field "flag" to filter out rejected for some reasons files 

WORKING_DIRECTORY = 'C:/BirdCLEF23/'
os.chdir (WORKING_DIRECTORY)

CONFIG = '_config.html'

cfg = pd.read_html (CONFIG)[0]
cfg.columns = ['param', 'value']

fpLog  = Path ('log files_v3.0.txt')

with open (fpLog, 'w') as flog:
    print ('files_v3.0 has started at : ', datetime.now(), file = flog)
    print ('CONFIG : \n', cfg, file = flog)

FILES = cfg.loc[(cfg['param'] == 'FILES'), ['value']].iloc[0]['value']
META = cfg.loc[(cfg['param'] == 'META'), ['value']].iloc[0]['value']
DIR_DATA = cfg.loc[(cfg['param'] == 'DIR_DATA'), ['value']].iloc[0]['value']
SR = cfg.loc[(cfg['param'] == 'SR'), ['value']].iloc[0].astype(int)['value']

with open (fpLog, 'a') as flog:
    print ('FILES : ', FILES, file = flog)
    print ('DIR_DATA : ', DIR_DATA, file = flog)
    print ('META : ', META, file = flog)
    print ('SR : ', SR, file = flog)

#SEED = 2276
#rng = default_rng (SEED)
#np.random.seed (SEED)
#random.seed (SEED)
#os.environ['PYTHONHASHSEED'] = str(SEED)
#tf.random.set_seed (SEED)


fp = Path (META)
df = pd.read_html (fp, encoding = 'UTF-8')[0] 
df.rename (columns = {"primary_label":"bird", "secondary_labels":"2lbl"}, inplace = True)

lini = [fname.replace ('\\', '/').replace ('//', '/') for fname in glob.glob (f'{DIR_DATA}/*/*.*')]

df['flag'] = True
df['fkey'] = df.filename.str.split('.').str.get(0)

dfl = pd.DataFrame ({'fname' : lini})
dfl['fkey'] = dfl.fname.str.split('/').str.get(-2) + '/' + dfl.fname.str.split('/').str.get(-1).str.split('.').str.get(0).str.split('M').str.get(0)
#dfl = dfl.merge (df[['bird', 'filename', 'fkey', '2lbl', 'rating', 'flag']], on = ['fkey'], how = 'left')
dfl = dfl.merge (df[['bird', 'fkey', '2lbl', 'rating', 'flag']], on = ['fkey'], how = 'left')
dfl.flag = dfl.flag.fillna (True) 

# adding transformed and new audios for rare birds

DIR_RARE = './config 264b v2.0/rare/'

lrare = [fname.replace ('\\', '/').replace ('//', '/') for fname in glob.glob (f'{DIR_RARE}/*/*.*')]
#dfr = pd.DataFrame().reindex_like (dfl.iloc[: len (lrare), :]).copy
dfr = pd.DataFrame ({'fname' : lrare})
dfr['fkey'] = dfr.fname.str.split('/').str.get(-2) + '/' + dfr.fname.str.split('/').str.get(-1).str.split('.').str.get(0).str.split('M').str.get(0)
dfr['bird'] = dfr.fname.str.split('/').str.get(-2)
#dfr['filename'] = dfr['fkey'] + '.ogg'
dfr['2lbl'] = '[]'
dfr['rating'] = 3.0
dfr['flag'] = True

#dfr.to_html ('./logs/test_dfr.html', encoding = 'UTF-8')
#dfl.to_html ('./logs/test_dfl.html', encoding = 'UTF-8')

dfl = pd.concat ([dfl, dfr], axis = 0).reset_index (drop = True)
#dfl.to_html ('./logs/test_all.html', encoding = 'UTF-8')

# List to remove from train data
# These are files where algorithm of marking up does not work for some reasones (noise and etc). 

ldel = [
'./data/train_audio/gyhneg1/XC476579.ogg',
'./data/train_audio/gyhneg1/XC343720.ogg',
'./data/train_audio/helgui/XC320655.ogg',
'./data/train_audio/helgui/XC200109.ogg',
'./data/train_audio/piecro1/XC195020.ogg',
'./data/train_audio/scthon1/XC429457.ogg',
'./data/train_audio/sltnig1/XC754004.ogg',
'./data/train_audio/sobfly1/XC153503.ogg',
'./data/train_audio/squher1/XC683187.ogg',
'./data/train_audio/strher/XC120021.ogg',
'./data/train_audio/strher/XC267140.ogg',
'./data/train_audio/strher/XC549360.ogg',
'./data/train_audio/strher/XC247433M3.wav',
'./data/train_audio/strher/XC247433M5.wav',
'./data/train_audio/tamdov1/XC515106M0.wav',
'./data/train_audio/tamdov1/XC515106M1.wav',
'./data/train_audio/tamdov1/XC515106M2.wav',
'./data/train_audio/tamdov1/XC515106M3.wav',
'./data/train_audio/tamdov1/XC285386.ogg',
'./data/train_audio/trobou1/XC196091.ogg',
'./data/train_audio/trobou1/XC195516.ogg',
'./data/train_audio/vilwea1/XC344677.ogg',
'./data/train_audio/walsta1/XC516790.ogg',
'./data/train_audio/whihel1/XC212794.ogg',
'./data/train_audio/woosan/XC669862.ogg',
'./data/train_audio/woosan/XC580553.ogg',
'./data/train_audio/yefcan/XC608858.ogg',
'./data/train_audio/yertin1/XC633863.ogg',
'./data/train_audio/yertin1/XC633772M0.wav',
'./data/train_audio/yertin1/XC634123M0.wav',
'./data/train_audio/yertin1/XC634123M1.wav',
'./data/train_audio/yertin1/XC634123M2.wav',
'./data/train_audio/yesbar1/XC419616M1.wav',
'./data/train_audio/yespet1/XC627250.ogg'
]

dfl.set_index (['fname'], inplace = True)

dfl.loc[ldel, 'flag'] = False

dfl.reset_index (inplace = True)

llen = []

for idx, row in dfl.iterrows():

    fname = row.fname; fp = Path (fname)

    try: 
        nax, _ = lba.load (fp, sr = SR, res_type = "kaiser_fast", mono = True)
        llen += [nax.shape[0]]
    except:
        with open (fpLog, 'a') as flog:
            print ('Error : ', fname, file = flog)
        llen += [np.nan]
        pass

dfl['duration'] = llen
dfl['length'] = dfl['duration']/SR

fp = Path (FILES)
dfl.to_html (fp, encoding = 'UTF-8')

with open (fpLog, 'a') as flog:
    print ('files_v3.0 has finished at : ', datetime.now(), file = flog)
